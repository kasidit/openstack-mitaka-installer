#!/bin/bash -x
/bin/date
./OS-installer-00-1-set-remote-access.sh
./OS-installer-00-2-update-ubuntu.sh
/bin/date
printf "continue part 2"
