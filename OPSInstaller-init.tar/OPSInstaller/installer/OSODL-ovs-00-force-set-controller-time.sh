#!/bin/bash
echo "set timezone of controller network compute"
ssh -t vasabi-1234loginname4321-ibasav@controller sudo timedatectl set-timezone vasabi-1234timezone4321-ibasav
ssh -t vasabi-1234loginname4321-ibasav@network sudo timedatectl set-timezone vasabi-1234timezone4321-ibasav
ssh -t vasabi-1234loginname4321-ibasav@compute sudo timedatectl set-timezone vasabi-1234timezone4321-ibasav
#ssh -t vasabi-1234loginname4321-ibasav@compute1 sudo timedatectl set-timezone vasabi-1234timezone4321-ibasav

echo "set date of controller network compute"
ssh -t vasabi-1234loginname4321-ibasav@controller sudo date --set=\"$(date)\"
ssh -t vasabi-1234loginname4321-ibasav@network sudo date --set=\"$(date)\"
ssh -t vasabi-1234loginname4321-ibasav@compute sudo date --set=\"$(date)\"
#ssh -t vasabi-1234loginname4321-ibasav@compute1 sudo date --set=\"$(date)\"
