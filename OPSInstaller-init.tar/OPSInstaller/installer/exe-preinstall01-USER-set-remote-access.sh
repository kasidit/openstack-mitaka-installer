# Openstack icehouse installation script on ubuntu 14.04 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2014  Kasidit Chanchio
#
#!/bin/bash -x 
#
#ssh-keygen -t rsa
#
echo "create new public-private keys"
#
rm /home/vasabi-1234loginname4321-ibasav/.ssh/*
#
./expectssh-keygen.sh
#
echo "accept host keys"
./expectsshyesno.sh vasabi-1234loginname4321-ibasav controller 
./expectsshyesno.sh vasabi-1234loginname4321-ibasav network
./expectsshyesno.sh vasabi-1234loginname4321-ibasav compute
./expectsshyesno.sh vasabi-1234loginname4321-ibasav compute1

echo "propagate credentials"
sshpass -pvasabi-1234loginpassword4321-ibasav scp /home/vasabi-1234loginname4321-ibasav/.ssh/id_rsa.pub vasabi-1234loginname4321-ibasav@controller:/home/vasabi-1234loginname4321-ibasav/authorized_keys
sshpass -pvasabi-1234loginpassword4321-ibasav scp /home/vasabi-1234loginname4321-ibasav/.ssh/id_rsa.pub vasabi-1234loginname4321-ibasav@network:/home/vasabi-1234loginname4321-ibasav/authorized_keys
sshpass -pvasabi-1234loginpassword4321-ibasav scp /home/vasabi-1234loginname4321-ibasav/.ssh/id_rsa.pub vasabi-1234loginname4321-ibasav@compute:/home/vasabi-1234loginname4321-ibasav/authorized_keys
sshpass -pvasabi-1234loginpassword4321-ibasav scp /home/vasabi-1234loginname4321-ibasav/.ssh/id_rsa.pub vasabi-1234loginname4321-ibasav@compute1:/home/vasabi-1234loginname4321-ibasav/authorized_keys

sshpass -pvasabi-1234loginpassword4321-ibasav ssh  vasabi-1234loginname4321-ibasav@controller "(mkdir /home/vasabi-1234loginname4321-ibasav/.ssh; mv /home/vasabi-1234loginname4321-ibasav/authorized_keys /home/vasabi-1234loginname4321-ibasav/.ssh/authorized_keys)"
sshpass -pvasabi-1234loginpassword4321-ibasav ssh  vasabi-1234loginname4321-ibasav@network "(mkdir /home/vasabi-1234loginname4321-ibasav/.ssh; mv /home/vasabi-1234loginname4321-ibasav/authorized_keys /home/vasabi-1234loginname4321-ibasav/.ssh/authorized_keys)"
sshpass -pvasabi-1234loginpassword4321-ibasav ssh  vasabi-1234loginname4321-ibasav@compute "(mkdir /home/vasabi-1234loginname4321-ibasav/.ssh; mv /home/vasabi-1234loginname4321-ibasav/authorized_keys /home/vasabi-1234loginname4321-ibasav/.ssh/authorized_keys)"
sshpass -pvasabi-1234loginpassword4321-ibasav ssh  vasabi-1234loginname4321-ibasav@compute1 "(mkdir /home/vasabi-1234loginname4321-ibasav/.ssh; mv /home/vasabi-1234loginname4321-ibasav/authorized_keys /home/vasabi-1234loginname4321-ibasav/.ssh/authorized_keys)"

echo "check date time of controller network compute"
ssh  vasabi-1234loginname4321-ibasav@controller date
ssh  vasabi-1234loginname4321-ibasav@network date
ssh  vasabi-1234loginname4321-ibasav@compute date
ssh  vasabi-1234loginname4321-ibasav@compute1 date

echo "set sudoers"
sshpass -pvasabi-1234loginpassword4321-ibasav scp files/adjustsudoer.sh vasabi-1234loginname4321-ibasav@controller:/home/vasabi-1234loginname4321-ibasav/adjustsudoer.sh
sshpass -pvasabi-1234loginpassword4321-ibasav scp files/adjustsudoer.sh vasabi-1234loginname4321-ibasav@network:/home/vasabi-1234loginname4321-ibasav/adjustsudoer.sh
sshpass -pvasabi-1234loginpassword4321-ibasav scp files/adjustsudoer.sh vasabi-1234loginname4321-ibasav@compute:/home/vasabi-1234loginname4321-ibasav/adjustsudoer.sh
sshpass -pvasabi-1234loginpassword4321-ibasav scp files/adjustsudoer.sh vasabi-1234loginname4321-ibasav@compute1:/home/vasabi-1234loginname4321-ibasav/adjustsudoer.sh

./expectsetsudoer.sh vasabi-1234loginname4321-ibasav controller vasabi-1234loginpassword4321-ibasav
./expectsetsudoer.sh vasabi-1234loginname4321-ibasav network vasabi-1234loginpassword4321-ibasav
./expectsetsudoer.sh vasabi-1234loginname4321-ibasav compute vasabi-1234loginpassword4321-ibasav
./expectsetsudoer.sh vasabi-1234loginname4321-ibasav compute1 vasabi-1234loginpassword4321-ibasav

echo "set timezone of controller network compute"
ssh -t vasabi-1234loginname4321-ibasav@controller sudo timedatectl set-timezone vasabi-1234timezone4321-ibasav
ssh -t vasabi-1234loginname4321-ibasav@network sudo timedatectl set-timezone vasabi-1234timezone4321-ibasav
ssh -t vasabi-1234loginname4321-ibasav@compute sudo timedatectl set-timezone vasabi-1234timezone4321-ibasav
ssh -t vasabi-1234loginname4321-ibasav@compute1 sudo timedatectl set-timezone vasabi-1234timezone4321-ibasav

echo "set date of controller network compute"
ssh -t vasabi-1234loginname4321-ibasav@controller sudo date --set=\"$(date)\"
ssh -t vasabi-1234loginname4321-ibasav@network sudo date --set=\"$(date)\"
ssh -t vasabi-1234loginname4321-ibasav@compute sudo date --set=\"$(date)\"
ssh -t vasabi-1234loginname4321-ibasav@compute1 sudo date --set=\"$(date)\"
