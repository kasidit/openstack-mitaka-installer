# Openstack icehouse installation script 
# on ubuntu 14.04 by kasidit chanchio
# vasabilab, dept of computer science, Thammasat University, Thailand
# copyright 2014 
#
#
#!/bin/bash -x
cd $HOME/OPSInstaller/controller
pwd
echo "Run this script as a user."
#read varkey

source ./admin-openrc.sh

neutron net-create ext-net --router:external \
   --provider:physical_network external --provider:network_type flat

neutron subnet-create ext-net vasabi-1234external_cidr4321-ibasav --name ext-subnet --allocation-pool start=vasabi-1234start_floating_ip4321-ibasav,end=vasabi-1234end_floating_ip4321-ibasav --disable-dhcp --gateway vasabi-1234gateway_ip4321-ibasav

source demo-openrc.sh

neutron net-create demo-net

neutron subnet-create demo-net 192.168.1.0/24 \
   --name demo-subnet --gateway 192.168.1.1

neutron router-create demo-router
neutron router-interface-add demo-router demo-subnet
neutron router-gateway-set demo-router ext-net

echo "wait 1 minute..."
sleep 60
echo "verify connectivity"
#read varkey
ping -c 4 vasabi-1234start_floating_ip4321-ibasav
