rm log/*
